package com.hotelbooking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class CancelBookingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int roomNo = Integer.parseInt(request.getParameter("room_no"));

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM bookings WHERE room_no = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, roomNo);
            int rows = stmt.executeUpdate();

            if (rows > 0) {
                response.getWriter().write("Booking cancelled successfully.");
            } else {
                response.getWriter().write("No booking found for Room No: " + roomNo);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        }
    }
}
