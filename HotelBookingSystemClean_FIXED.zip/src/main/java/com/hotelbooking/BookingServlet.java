package com.hotelbooking;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get values from form
        String name = request.getParameter("name");
        String roomNo = request.getParameter("room_no");
        String checkin = request.getParameter("checkin");
        String checkout = request.getParameter("checkout");

        // Get DB connection
        Connection conn = DBConnection.getConnection();

        if (conn == null) {
            out.println("<h3>❌ Failed to connect to the database. Please check your DB settings.</h3>");
            return;
        }

        try {
            String sql = "INSERT INTO bookings (name, room_no, checkin, checkout) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setInt(2, Integer.parseInt(roomNo));
            stmt.setString(3, checkin);
            stmt.setString(4, checkout);

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                out.println("<h3>✅ Room booked successfully!</h3>");
            } else {
                out.println("<h3>⚠️ Booking failed. Try again.</h3>");
            }

            stmt.close();
            conn.close();

        } catch (Exception e) {
            out.println("<h3>🚫 Error occurred: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        }
    }
}
