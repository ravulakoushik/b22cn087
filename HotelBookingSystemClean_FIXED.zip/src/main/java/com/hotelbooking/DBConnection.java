package com.hotelbooking;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() {
        Connection conn = null;
        try {
            System.out.println("⏳ Loading MySQL driver...");
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("✅ Driver loaded. Connecting to DB...");

            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/hotel_project_db?useSSL=false&serverTimezone=UTC", 
                "root", 
                "" // No password
            );

            System.out.println("✅ Connected to database");
        } catch (Exception e) {
            System.out.println("❌ DB Connection Failed:");
            e.printStackTrace();
        }
        return conn;
    }
}